#!/bin/bash

echo `date`
#iptables -I FORWARD 1 -s $1 -p tcp --dport 3724 -j DROP
#iptables -I FORWARD 1 -s $1 -p tcp --dport 6112 -j DROP
#iptables -I FORWARD 1 -s $1 -p tcp --dport 6881:6999 -j DROP
/sbin/iptables -I FORWARD 1 -p tcp --dport 3724 -j DROP
/sbin/iptables -I FORWARD 1 -p tcp --dport 6112 -j DROP
/sbin/iptables -I FORWARD 1 -p tcp --dport 6881:6999 -j DROP
