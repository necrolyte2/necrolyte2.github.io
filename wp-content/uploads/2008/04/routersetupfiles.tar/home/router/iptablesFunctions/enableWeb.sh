#!/bin/bash

echo `date`
/sbin/iptables -D FORWARD -p tcp --dport 80 -j DROP
