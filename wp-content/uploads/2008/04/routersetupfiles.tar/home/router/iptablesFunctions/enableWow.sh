#!/bin/bash

echo `date`
#iptables -D FORWARD -s $1 -p tcp --dport 3724 -j DROP
#iptables -D FORWARD -s $1 -p tcp --dport 6112 -j DROP
#iptables -D FORWARD -s $1 -p tcp --dport 6881:6999 -j DROP
/sbin/iptables -D FORWARD -p tcp --dport 3724 -j DROP
/sbin/iptables -D FORWARD -p tcp --dport 6112 -j DROP
/sbin/iptables -D FORWARD -p tcp --dport 6881:6999 -j DROP
