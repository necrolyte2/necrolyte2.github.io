#!/bin/bash

echo `date`
/sbin/iptables -I FORWARD 1 -p tcp --dport 80 -j DROP
